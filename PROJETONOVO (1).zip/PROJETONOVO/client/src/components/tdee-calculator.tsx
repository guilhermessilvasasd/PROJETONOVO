import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calculator, Activity, Target } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TDEEResult {
  bmr: number;
  tdee: number;
  goal_calories: number;
  macros: {
    protein_min: number;
    protein_max: number;
    fat_min: number;
    fat_max: number;
    carbs_min: number;
    carbs_max: number;
  };
}

export function TDEECalculator() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TDEEResult | null>(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    idade: "",
    peso: "",
    altura: "",
    sexo: "masculino",
    nivel_atividade: "moderado",
    objetivo: "manutencao",
  });

  const handleCalculate = async () => {
    if (!formData.idade || !formData.peso || !formData.altura) {
      toast({
        title: "Preencha todos os campos",
        description: "Idade, peso e altura são obrigatórios",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const response = await apiRequest("POST", "/api/calculate-tdee", {
        idade: parseInt(formData.idade),
        peso: parseFloat(formData.peso),
        altura: parseFloat(formData.altura),
        sexo: formData.sexo,
        nivel_atividade: formData.nivel_atividade,
        objetivo: formData.objetivo,
      });

      const data = await response.json();
      setResult(data);
      
      toast({
        title: "Cálculo realizado!",
        description: "Suas necessidades calóricas foram calculadas com sucesso",
      });
    } catch (error) {
      toast({
        title: "Erro ao calcular",
        description: "Não foi possível calcular o TDEE. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Calculadora de TDEE e Calorias
          </CardTitle>
          <CardDescription>
            Calcule suas necessidades calóricas diárias baseadas na fórmula Mifflin-St Jeor
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="idade">Idade (anos)</Label>
              <Input
                id="idade"
                type="number"
                placeholder="Ex: 25"
                value={formData.idade}
                onChange={(e) => setFormData({ ...formData, idade: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="peso">Peso (kg)</Label>
              <Input
                id="peso"
                type="number"
                step="0.1"
                placeholder="Ex: 75.5"
                value={formData.peso}
                onChange={(e) => setFormData({ ...formData, peso: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="altura">Altura (cm)</Label>
              <Input
                id="altura"
                type="number"
                placeholder="Ex: 175"
                value={formData.altura}
                onChange={(e) => setFormData({ ...formData, altura: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="sexo">Sexo</Label>
              <Select
                value={formData.sexo}
                onValueChange={(value) => setFormData({ ...formData, sexo: value })}
              >
                <SelectTrigger id="sexo">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="masculino">Masculino</SelectItem>
                  <SelectItem value="feminino">Feminino</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="atividade">Nível de Atividade</Label>
              <Select
                value={formData.nivel_atividade}
                onValueChange={(value) => setFormData({ ...formData, nivel_atividade: value })}
              >
                <SelectTrigger id="atividade">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sedentario">Sedentário (pouco ou nenhum exercício)</SelectItem>
                  <SelectItem value="leve">Leve (1-3 dias/semana)</SelectItem>
                  <SelectItem value="moderado">Moderado (3-5 dias/semana)</SelectItem>
                  <SelectItem value="intenso">Intenso (6-7 dias/semana)</SelectItem>
                  <SelectItem value="muito_intenso">Muito Intenso (2x ao dia)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="objetivo">Objetivo</Label>
              <Select
                value={formData.objetivo}
                onValueChange={(value) => setFormData({ ...formData, objetivo: value })}
              >
                <SelectTrigger id="objetivo">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cutting">Perda de Peso (Cutting)</SelectItem>
                  <SelectItem value="cutting_moderado">Perda Moderada</SelectItem>
                  <SelectItem value="manutencao">Manutenção</SelectItem>
                  <SelectItem value="bulking_moderado">Ganho Moderado</SelectItem>
                  <SelectItem value="bulking">Ganho de Massa (Bulking)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button onClick={handleCalculate} disabled={loading} className="w-full">
            <Calculator className="h-4 w-4 mr-2" />
            {loading ? "Calculando..." : "Calcular TDEE"}
          </Button>
        </CardContent>
      </Card>

      {result && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Suas Necessidades Calóricas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Taxa Metabólica Basal (BMR)</span>
                  <span className="text-lg font-semibold">{Math.round(result.bmr)} kcal</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Calorias que seu corpo queima em repouso
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Gasto Calórico Total (TDEE)</span>
                  <span className="text-lg font-semibold">{Math.round(result.tdee)} kcal</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Calorias que você gasta por dia com suas atividades
                </p>
              </div>

              <div className="space-y-2 pt-4 border-t">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium flex items-center gap-2">
                    <Target className="h-4 w-4" />
                    Meta Calórica Diária
                  </span>
                  <span className="text-2xl font-bold text-primary">
                    {Math.round(result.goal_calories)} kcal
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Calorias recomendadas para atingir seu objetivo
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Distribuição de Macronutrientes</CardTitle>
              <CardDescription>Faixas recomendadas para seu objetivo</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">🥩 Proteínas</span>
                  <span className="text-sm font-semibold">
                    {Math.round(result.macros.protein_min)}g - {Math.round(result.macros.protein_max)}g
                  </span>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-red-500" style={{ width: "30%" }} />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">🍚 Carboidratos</span>
                  <span className="text-sm font-semibold">
                    {Math.round(result.macros.carbs_min)}g - {Math.round(result.macros.carbs_max)}g
                  </span>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500" style={{ width: "45%" }} />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">🥑 Gorduras</span>
                  <span className="text-sm font-semibold">
                    {Math.round(result.macros.fat_min)}g - {Math.round(result.macros.fat_max)}g
                  </span>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-yellow-500" style={{ width: "25%" }} />
                </div>
              </div>

              <div className="pt-4 border-t">
                <p className="text-xs text-muted-foreground">
                  💡 Estes valores são uma faixa recomendada. Ajuste conforme seus resultados e preferências.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
