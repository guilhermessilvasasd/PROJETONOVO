import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dumbbell, Calendar } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface WorkoutExercise {
  id: string;
  exercicio: string;
  series: number;
  repeticoes: number;
  peso: string;
  observacoes?: string;
  ordem: number;
}

interface WorkoutPlan {
  id: string;
  nome: string;
  descricao: string;
  categoria: string;
  data_criacao: string;
  exercicios: WorkoutExercise[];
}

export function WorkoutPlansViewer() {
  const { data: plans = [], isLoading } = useQuery<WorkoutPlan[]>({
    queryKey: ["/api/workout-plans"],
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-6 w-64" />
              <Skeleton className="h-4 w-full" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-32 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (plans.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Dumbbell className="h-12 w-12 text-muted-foreground mb-4" />
          <p className="text-muted-foreground text-center">
            Nenhum plano de treino encontrado.
            <br />
            <span className="text-xs">
              Os planos de exemplo serão carregados automaticamente ao reiniciar o servidor.
            </span>
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Planos de Treino Completos</h2>
          <p className="text-sm text-muted-foreground">
            {plans.length} plano{plans.length !== 1 ? "s" : ""} disponível{plans.length !== 1 ? "is" : ""}
          </p>
        </div>
      </div>

      <div className="grid gap-6">
        {plans.map((plan) => (
          <Card key={plan.id} className="overflow-hidden">
            <CardHeader className="bg-muted/50">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <CardTitle className="flex items-center gap-2">
                    <Dumbbell className="h-5 w-5" />
                    {plan.nome}
                  </CardTitle>
                  <CardDescription>{plan.descricao}</CardDescription>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <Badge variant="secondary">{plan.categoria}</Badge>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    {new Date(plan.data_criacao).toLocaleDateString("pt-BR")}
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-semibold">
                    {plan.exercicios.length} exercício{plan.exercicios.length !== 1 ? "s" : ""}
                  </span>
                  <span className="text-muted-foreground">
                    Total: {plan.exercicios.reduce((sum, ex) => sum + ex.series, 0)} séries
                  </span>
                </div>

                <div className="space-y-3">
                  {plan.exercicios
                    .sort((a, b) => a.ordem - b.ordem)
                    .map((exercise, idx) => (
                      <div
                        key={exercise.id}
                        className="flex items-start gap-4 p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                      >
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
                          {idx + 1}
                        </div>
                        <div className="flex-1 space-y-1">
                          <h4 className="font-semibold">{exercise.exercicio}</h4>
                          <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
                            <span>
                              <strong className="text-foreground">{exercise.series}</strong> séries
                            </span>
                            <span>•</span>
                            <span>
                              <strong className="text-foreground">{exercise.repeticoes}</strong> reps
                            </span>
                            {exercise.peso && exercise.peso !== "0" && (
                              <>
                                <span>•</span>
                                <span>
                                  <strong className="text-foreground">{exercise.peso}</strong> kg
                                </span>
                              </>
                            )}
                          </div>
                          {exercise.observacoes && (
                            <p className="text-xs text-muted-foreground italic">
                              💡 {exercise.observacoes}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-dashed">
        <CardContent className="pt-6">
          <div className="text-center space-y-2">
            <p className="text-sm font-medium">💡 Quer adicionar mais planos?</p>
            <p className="text-xs text-muted-foreground">
              Edite o arquivo <code className="bg-muted px-1 py-0.5 rounded">server/seed-workout-examples.ts</code> e adicione seus próprios planos de treino.
              <br />
              Procure pelos comentários <code className="bg-muted px-1 py-0.5 rounded">💡 ADICIONE MAIS PLANOS AQUI</code>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
