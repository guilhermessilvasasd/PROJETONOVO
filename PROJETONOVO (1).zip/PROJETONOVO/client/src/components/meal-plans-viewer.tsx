import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { UtensilsCrossed, Calendar, Flame } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface MealItem {
  id: string;
  nome: string;
  refeicao: string;
  calorias: number;
  proteinas: string;
  carboidratos: string;
  gorduras: string;
  observacoes?: string;
  ordem: number;
}

interface MealPlan {
  id: string;
  nome: string;
  descricao: string;
  calorias_totais: number;
  data_criacao: string;
  refeicoes: MealItem[];
}

const refeicaoLabels: Record<string, string> = {
  cafe: "Café da Manhã",
  lanche_manha: "Lanche da Manhã",
  almoco: "Almoço",
  lanche_tarde: "Lanche da Tarde",
  jantar: "Jantar",
  ceia: "Ceia",
};

const refeicaoEmojis: Record<string, string> = {
  cafe: "🌅",
  lanche_manha: "🍎",
  almoco: "🍽️",
  lanche_tarde: "🥤",
  jantar: "🌙",
  ceia: "🌜",
};

export function MealPlansViewer() {
  const { data: plans = [], isLoading } = useQuery<MealPlan[]>({
    queryKey: ["/api/meal-plans"],
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-6 w-64" />
              <Skeleton className="h-4 w-full" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-32 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (plans.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <UtensilsCrossed className="h-12 w-12 text-muted-foreground mb-4" />
          <p className="text-muted-foreground text-center">
            Nenhum plano alimentar encontrado.
            <br />
            <span className="text-xs">
              Os planos de exemplo serão carregados automaticamente ao reiniciar o servidor.
            </span>
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Planos Alimentares Completos</h2>
          <p className="text-sm text-muted-foreground">
            {plans.length} plano{plans.length !== 1 ? "s" : ""} disponível{plans.length !== 1 ? "is" : ""}
          </p>
        </div>
      </div>

      <div className="grid gap-6">
        {plans.map((plan) => {
          const totalProteinas = plan.refeicoes.reduce(
            (sum, r) => sum + parseFloat(r.proteinas || "0"),
            0
          );
          const totalCarbs = plan.refeicoes.reduce(
            (sum, r) => sum + parseFloat(r.carboidratos || "0"),
            0
          );
          const totalGorduras = plan.refeicoes.reduce(
            (sum, r) => sum + parseFloat(r.gorduras || "0"),
            0
          );

          return (
            <Card key={plan.id} className="overflow-hidden">
              <CardHeader className="bg-muted/50">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <CardTitle className="flex items-center gap-2">
                      <UtensilsCrossed className="h-5 w-5" />
                      {plan.nome}
                    </CardTitle>
                    <CardDescription>{plan.descricao}</CardDescription>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <Badge variant="default" className="gap-1">
                      <Flame className="h-3 w-3" />
                      {plan.calorias_totais} kcal
                    </Badge>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      {new Date(plan.data_criacao).toLocaleDateString("pt-BR")}
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4 p-4 bg-muted/50 rounded-lg">
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground mb-1">Proteínas</p>
                      <p className="text-lg font-bold">🥩 {Math.round(totalProteinas)}g</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground mb-1">Carboidratos</p>
                      <p className="text-lg font-bold">🍚 {Math.round(totalCarbs)}g</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground mb-1">Gorduras</p>
                      <p className="text-lg font-bold">🥑 {Math.round(totalGorduras)}g</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {plan.refeicoes
                      .sort((a, b) => a.ordem - b.ordem)
                      .map((meal) => (
                        <div
                          key={meal.id}
                          className="p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <span className="text-xl">
                                {refeicaoEmojis[meal.refeicao] || "🍽️"}
                              </span>
                              <div>
                                <p className="text-xs text-muted-foreground">
                                  {refeicaoLabels[meal.refeicao] || meal.refeicao}
                                </p>
                                <h4 className="font-semibold">{meal.nome}</h4>
                              </div>
                            </div>
                            <Badge variant="outline" className="shrink-0">
                              {meal.calorias} kcal
                            </Badge>
                          </div>

                          <div className="grid grid-cols-3 gap-3 text-sm mt-3">
                            <div className="text-center p-2 bg-muted/50 rounded">
                              <p className="text-xs text-muted-foreground">Proteínas</p>
                              <p className="font-semibold">{meal.proteinas}g</p>
                            </div>
                            <div className="text-center p-2 bg-muted/50 rounded">
                              <p className="text-xs text-muted-foreground">Carboidratos</p>
                              <p className="font-semibold">{meal.carboidratos}g</p>
                            </div>
                            <div className="text-center p-2 bg-muted/50 rounded">
                              <p className="text-xs text-muted-foreground">Gorduras</p>
                              <p className="font-semibold">{meal.gorduras}g</p>
                            </div>
                          </div>

                          {meal.observacoes && (
                            <p className="text-xs text-muted-foreground italic mt-2 border-t pt-2">
                              💡 {meal.observacoes}
                            </p>
                          )}
                        </div>
                      ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="border-dashed">
        <CardContent className="pt-6">
          <div className="text-center space-y-2">
            <p className="text-sm font-medium">💡 Quer adicionar mais planos?</p>
            <p className="text-xs text-muted-foreground">
              Edite o arquivo <code className="bg-muted px-1 py-0.5 rounded">server/seed-workout-examples.ts</code> e adicione seus próprios planos alimentares.
              <br />
              Procure pelos comentários <code className="bg-muted px-1 py-0.5 rounded">💡 ADICIONE MAIS PLANOS AQUI</code>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
