export interface TDEEResult {
  tmb: number;
  tdee: number;
  calorias_objetivo: number;
  proteinas: number;
  carboidratos: number;
  gorduras: number;
}

const ACTIVITY_MULTIPLIERS = {
  sedentario: 1.2,
  leve: 1.375,
  moderado: 1.55,
  intenso: 1.725,
  muito_intenso: 1.9,
};

const OBJECTIVE_ADJUSTMENTS = {
  perder_peso: -500,
  manter_peso: 0,
  ganhar_massa: 500,
};

export function calculateTDEE(
  peso: number,
  altura: number,
  idade: number,
  sexo: "masculino" | "feminino",
  nivelAtividade: keyof typeof ACTIVITY_MULTIPLIERS,
  objetivo: keyof typeof OBJECTIVE_ADJUSTMENTS
): TDEEResult {
  let tmb: number;

  if (sexo === "masculino") {
    tmb = 10 * peso + 6.25 * altura - 5 * idade + 5;
  } else {
    tmb = 10 * peso + 6.25 * altura - 5 * idade - 161;
  }

  const tdee = tmb * ACTIVITY_MULTIPLIERS[nivelAtividade];

  const caloriasObjetivo = tdee + OBJECTIVE_ADJUSTMENTS[objetivo];

  const proteinas = peso * 2.2;
  const gorduras = (caloriasObjetivo * 0.25) / 9;
  const carboidratos = (caloriasObjetivo - (proteinas * 4 + gorduras * 9)) / 4;

  return {
    tmb: Math.round(tmb),
    tdee: Math.round(tdee),
    calorias_objetivo: Math.round(caloriasObjetivo),
    proteinas: Math.round(proteinas),
    carboidratos: Math.round(carboidratos),
    gorduras: Math.round(gorduras),
  };
}

export function getActivityLevel(nivel: string): string {
  const levels: Record<string, string> = {
    sedentario: "Sedentário (pouco ou nenhum exercício)",
    leve: "Levemente ativo (exercício 1-3 dias/semana)",
    moderado: "Moderadamente ativo (exercício 3-5 dias/semana)",
    intenso: "Muito ativo (exercício 6-7 dias/semana)",
    muito_intenso: "Extremamente ativo (exercício 2x/dia ou trabalho físico)",
  };
  return levels[nivel] || nivel;
}

export function getObjectiveDescription(objetivo: string): string {
  const objectives: Record<string, string> = {
    perder_peso: "Perder Peso (-500 kcal)",
    manter_peso: "Manter Peso",
    ganhar_massa: "Ganhar Massa Muscular (+500 kcal)",
  };
  return objectives[objetivo] || objetivo;
}
