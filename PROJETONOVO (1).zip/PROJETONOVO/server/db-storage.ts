import { eq, desc } from "drizzle-orm";
import { db } from "./db";
import { 
  users,
  finances,
  workouts,
  meals,
  tasks,
  studies,
  workoutPlans,
  workoutPlanExercises,
  mealPlans,
  mealPlanItems,
  userMetrics,
  type User, 
  type InsertUser,
  type Finance,
  type InsertFinance,
  type Workout,
  type InsertWorkout,
  type Meal,
  type InsertMeal,
  type Task,
  type InsertTask,
  type Study,
  type InsertStudy,
  type WorkoutPlan,
  type WorkoutPlanExercise,
  type InsertWorkoutPlan,
  type MealPlan,
  type MealPlanItem,
  type InsertMealPlan,
  type UserMetrics,
  type InsertUserMetrics
} from "@shared/schema";
import type { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async getFinances(): Promise<Finance[]> {
    return await db.select().from(finances).orderBy(desc(finances.data));
  }

  async getFinance(id: string): Promise<Finance | undefined> {
    const result = await db.select().from(finances).where(eq(finances.id, id));
    return result[0];
  }

  async createFinance(finance: InsertFinance): Promise<Finance> {
    const result = await db.insert(finances).values(finance).returning();
    return result[0];
  }

  async updateFinance(id: string, finance: InsertFinance): Promise<Finance | undefined> {
    const result = await db.update(finances).set(finance).where(eq(finances.id, id)).returning();
    return result[0];
  }

  async deleteFinance(id: string): Promise<boolean> {
    const result = await db.delete(finances).where(eq(finances.id, id)).returning();
    return result.length > 0;
  }

  async getWorkouts(): Promise<Workout[]> {
    return await db.select().from(workouts).orderBy(desc(workouts.data));
  }

  async getWorkout(id: string): Promise<Workout | undefined> {
    const result = await db.select().from(workouts).where(eq(workouts.id, id));
    return result[0];
  }

  async createWorkout(workout: InsertWorkout): Promise<Workout> {
    const result = await db.insert(workouts).values(workout).returning();
    return result[0];
  }

  async updateWorkout(id: string, workout: InsertWorkout): Promise<Workout | undefined> {
    const result = await db.update(workouts).set(workout).where(eq(workouts.id, id)).returning();
    return result[0];
  }

  async deleteWorkout(id: string): Promise<boolean> {
    const result = await db.delete(workouts).where(eq(workouts.id, id)).returning();
    return result.length > 0;
  }

  async getMeals(): Promise<Meal[]> {
    return await db.select().from(meals).orderBy(desc(meals.data));
  }

  async getMeal(id: string): Promise<Meal | undefined> {
    const result = await db.select().from(meals).where(eq(meals.id, id));
    return result[0];
  }

  async createMeal(meal: InsertMeal): Promise<Meal> {
    const result = await db.insert(meals).values(meal).returning();
    return result[0];
  }

  async updateMeal(id: string, meal: InsertMeal): Promise<Meal | undefined> {
    const result = await db.update(meals).set(meal).where(eq(meals.id, id)).returning();
    return result[0];
  }

  async deleteMeal(id: string): Promise<boolean> {
    const result = await db.delete(meals).where(eq(meals.id, id)).returning();
    return result.length > 0;
  }

  async getTasks(): Promise<Task[]> {
    return await db.select().from(tasks).orderBy(desc(tasks.data));
  }

  async getTask(id: string): Promise<Task | undefined> {
    const result = await db.select().from(tasks).where(eq(tasks.id, id));
    return result[0];
  }

  async createTask(task: InsertTask): Promise<Task> {
    const result = await db.insert(tasks).values(task).returning();
    return result[0];
  }

  async updateTask(id: string, task: InsertTask): Promise<Task | undefined> {
    const result = await db.update(tasks).set(task).where(eq(tasks.id, id)).returning();
    return result[0];
  }

  async deleteTask(id: string): Promise<boolean> {
    const result = await db.delete(tasks).where(eq(tasks.id, id)).returning();
    return result.length > 0;
  }

  async getStudies(): Promise<Study[]> {
    return await db.select().from(studies).orderBy(desc(studies.progresso));
  }

  async getStudy(id: string): Promise<Study | undefined> {
    const result = await db.select().from(studies).where(eq(studies.id, id));
    return result[0];
  }

  async createStudy(study: InsertStudy): Promise<Study> {
    const result = await db.insert(studies).values(study).returning();
    return result[0];
  }

  async updateStudy(id: string, study: InsertStudy): Promise<Study | undefined> {
    const result = await db.update(studies).set(study).where(eq(studies.id, id)).returning();
    return result[0];
  }

  async deleteStudy(id: string): Promise<boolean> {
    const result = await db.delete(studies).where(eq(studies.id, id)).returning();
    return result.length > 0;
  }

  async getWorkoutPlans(): Promise<(WorkoutPlan & { exercicios: WorkoutPlanExercise[] })[]> {
    const plans = await db.select().from(workoutPlans).orderBy(desc(workoutPlans.data_criacao));
    const result = [];
    
    for (const plan of plans) {
      const exercicios = await db.select().from(workoutPlanExercises)
        .where(eq(workoutPlanExercises.workout_plan_id, plan.id))
        .orderBy(workoutPlanExercises.ordem);
      result.push({ ...plan, exercicios });
    }
    
    return result;
  }

  async getWorkoutPlan(id: string): Promise<(WorkoutPlan & { exercicios: WorkoutPlanExercise[] }) | undefined> {
    const planResult = await db.select().from(workoutPlans).where(eq(workoutPlans.id, id));
    if (!planResult[0]) return undefined;
    
    const exercicios = await db.select().from(workoutPlanExercises)
      .where(eq(workoutPlanExercises.workout_plan_id, id))
      .orderBy(workoutPlanExercises.ordem);
    
    return { ...planResult[0], exercicios };
  }

  async createWorkoutPlan(plan: InsertWorkoutPlan): Promise<WorkoutPlan & { exercicios: WorkoutPlanExercise[] }> {
    const { exercicios, ...planData } = plan;
    const planResult = await db.insert(workoutPlans).values(planData).returning();
    const createdPlan = planResult[0];
    
    const exerciciosData = exercicios.map((ex, index) => ({
      workout_plan_id: createdPlan.id,
      exercicio: ex.exercicio,
      series: ex.series,
      repeticoes: ex.repeticoes,
      peso: ex.peso || null,
      observacoes: ex.observacoes || null,
      ordem: index + 1,
    }));
    
    const createdExercicios = await db.insert(workoutPlanExercises)
      .values(exerciciosData)
      .returning();
    
    return { ...createdPlan, exercicios: createdExercicios };
  }

  async deleteWorkoutPlan(id: string): Promise<boolean> {
    await db.delete(workoutPlanExercises).where(eq(workoutPlanExercises.workout_plan_id, id));
    const result = await db.delete(workoutPlans).where(eq(workoutPlans.id, id)).returning();
    return result.length > 0;
  }

  async getMealPlans(): Promise<(MealPlan & { refeicoes: MealPlanItem[] })[]> {
    const plans = await db.select().from(mealPlans).orderBy(desc(mealPlans.data_criacao));
    const result = [];
    
    for (const plan of plans) {
      const refeicoes = await db.select().from(mealPlanItems)
        .where(eq(mealPlanItems.meal_plan_id, plan.id))
        .orderBy(mealPlanItems.ordem);
      result.push({ ...plan, refeicoes });
    }
    
    return result;
  }

  async getMealPlan(id: string): Promise<(MealPlan & { refeicoes: MealPlanItem[] }) | undefined> {
    const planResult = await db.select().from(mealPlans).where(eq(mealPlans.id, id));
    if (!planResult[0]) return undefined;
    
    const refeicoes = await db.select().from(mealPlanItems)
      .where(eq(mealPlanItems.meal_plan_id, id))
      .orderBy(mealPlanItems.ordem);
    
    return { ...planResult[0], refeicoes };
  }

  async createMealPlan(plan: InsertMealPlan): Promise<MealPlan & { refeicoes: MealPlanItem[] }> {
    const { refeicoes, ...planData } = plan;
    const planResult = await db.insert(mealPlans).values(planData).returning();
    const createdPlan = planResult[0];
    
    const refeicoesData = refeicoes.map((ref, index) => ({
      meal_plan_id: createdPlan.id,
      nome: ref.nome,
      refeicao: ref.refeicao,
      calorias: ref.calorias || null,
      proteinas: ref.proteinas || null,
      carboidratos: ref.carboidratos || null,
      gorduras: ref.gorduras || null,
      observacoes: ref.observacoes || null,
      ordem: index + 1,
    }));
    
    const createdRefeicoes = await db.insert(mealPlanItems)
      .values(refeicoesData)
      .returning();
    
    return { ...createdPlan, refeicoes: createdRefeicoes };
  }

  async deleteMealPlan(id: string): Promise<boolean> {
    await db.delete(mealPlanItems).where(eq(mealPlanItems.meal_plan_id, id));
    const result = await db.delete(mealPlans).where(eq(mealPlans.id, id)).returning();
    return result.length > 0;
  }

  async getUserMetrics(): Promise<UserMetrics | undefined> {
    const result = await db.select().from(userMetrics).orderBy(desc(userMetrics.data_atualizacao));
    return result[0];
  }

  async createOrUpdateUserMetrics(metrics: InsertUserMetrics): Promise<UserMetrics> {
    const existing = await this.getUserMetrics();
    
    if (existing) {
      const result = await db.update(userMetrics)
        .set(metrics)
        .where(eq(userMetrics.id, existing.id))
        .returning();
      return result[0];
    } else {
      const result = await db.insert(userMetrics).values(metrics).returning();
      return result[0];
    }
  }
}
