// ============================================================================
// BANCO DE DADOS DE ALIMENTOS COM MACROS
// ============================================================================
// 💡 ADICIONE SEUS PRÓPRIOS ALIMENTOS AQUI - Copie o formato e adicione novos
// ============================================================================
// Valores nutricionais por 100g do alimento cru/cozido conforme especificado
// ============================================================================

export interface FoodItem {
  nome: string;
  categoria: string;
  calorias: number;  // kcal por 100g
  proteinas: number; // gramas por 100g
  carboidratos: number; // gramas por 100g
  gorduras: number;  // gramas por 100g
  porcao_referencia?: string; // Tamanho de porção padrão para referência
}

// ============================================================================
// PROTEÍNAS ANIMAIS
// ============================================================================
export const proteinasAnimais: FoodItem[] = [
  {
    nome: "Peito de Frango (grelhado)",
    categoria: "Proteína Animal",
    calorias: 165,
    proteinas: 31,
    carboidratos: 0,
    gorduras: 3.6,
    porcao_referencia: "1 peito médio = 200g"
  },
  {
    nome: "Filé de Tilápia (grelhado)",
    categoria: "Proteína Animal",
    calorias: 129,
    proteinas: 26,
    carboidratos: 0,
    gorduras: 2.7,
    porcao_referencia: "1 filé médio = 150g"
  },
  {
    nome: "Salmão (grelhado)",
    categoria: "Proteína Animal",
    calorias: 206,
    proteinas: 25,
    carboidratos: 0,
    gorduras: 12,
    porcao_referencia: "1 filé = 180g"
  },
  {
    nome: "Carne Vermelha Magra (patinho)",
    categoria: "Proteína Animal",
    calorias: 158,
    proteinas: 27,
    carboidratos: 0,
    gorduras: 5,
    porcao_referencia: "1 bife médio = 150g"
  },
  {
    nome: "Atum em Lata (ao natural)",
    categoria: "Proteína Animal",
    calorias: 116,
    proteinas: 26,
    carboidratos: 0,
    gorduras: 0.8,
    porcao_referencia: "1 lata = 140g"
  },
  {
    nome: "Ovo Inteiro (cozido)",
    categoria: "Proteína Animal",
    calorias: 155,
    proteinas: 13,
    carboidratos: 1.1,
    gorduras: 11,
    porcao_referencia: "1 ovo grande = 50g"
  },
  {
    nome: "Clara de Ovo",
    categoria: "Proteína Animal",
    calorias: 52,
    proteinas: 11,
    carboidratos: 0.7,
    gorduras: 0.2,
    porcao_referencia: "1 clara = 33g"
  },
  // 💡 ADICIONE MAIS PROTEÍNAS ANIMAIS AQUI
];

// ============================================================================
// CARBOIDRATOS COMPLEXOS
// ============================================================================
export const carboidratosComplexos: FoodItem[] = [
  {
    nome: "Arroz Integral (cozido)",
    categoria: "Carboidrato Complexo",
    calorias: 123,
    proteinas: 2.6,
    carboidratos: 26,
    gorduras: 1,
    porcao_referencia: "1 xícara = 195g"
  },
  {
    nome: "Arroz Branco (cozido)",
    categoria: "Carboidrato Complexo",
    calorias: 130,
    proteinas: 2.7,
    carboidratos: 28,
    gorduras: 0.3,
    porcao_referencia: "1 xícara = 195g"
  },
  {
    nome: "Batata Doce (cozida)",
    categoria: "Carboidrato Complexo",
    calorias: 90,
    proteinas: 2,
    carboidratos: 21,
    gorduras: 0.2,
    porcao_referencia: "1 batata média = 150g"
  },
  {
    nome: "Batata Inglesa (cozida)",
    categoria: "Carboidrato Complexo",
    calorias: 87,
    proteinas: 1.9,
    carboidratos: 20,
    gorduras: 0.1,
    porcao_referencia: "1 batata média = 150g"
  },
  {
    nome: "Aveia em Flocos",
    categoria: "Carboidrato Complexo",
    calorias: 389,
    proteinas: 17,
    carboidratos: 66,
    gorduras: 7,
    porcao_referencia: "1/2 xícara = 50g"
  },
  {
    nome: "Macarrão Integral (cozido)",
    categoria: "Carboidrato Complexo",
    calorias: 124,
    proteinas: 5,
    carboidratos: 26,
    gorduras: 0.5,
    porcao_referencia: "1 xícara = 140g"
  },
  {
    nome: "Quinoa (cozida)",
    categoria: "Carboidrato Complexo",
    calorias: 120,
    proteinas: 4.4,
    carboidratos: 21,
    gorduras: 1.9,
    porcao_referencia: "1 xícara = 185g"
  },
  {
    nome: "Pão Integral (fatia)",
    categoria: "Carboidrato Complexo",
    calorias: 247,
    proteinas: 13,
    carboidratos: 41,
    gorduras: 3.4,
    porcao_referencia: "1 fatia = 30g"
  },
  {
    nome: "Tapioca (goma hidratada)",
    categoria: "Carboidrato Complexo",
    calorias: 358,
    proteinas: 0.3,
    carboidratos: 88,
    gorduras: 0.1,
    porcao_referencia: "1/2 xícara = 50g"
  },
  // 💡 ADICIONE MAIS CARBOIDRATOS COMPLEXOS AQUI
];

// ============================================================================
// GORDURAS SAUDÁVEIS
// ============================================================================
export const gordurasSaudaveis: FoodItem[] = [
  {
    nome: "Abacate",
    categoria: "Gordura Saudável",
    calorias: 160,
    proteinas: 2,
    carboidratos: 9,
    gorduras: 15,
    porcao_referencia: "1/2 abacate = 100g"
  },
  {
    nome: "Pasta de Amendoim (integral)",
    categoria: "Gordura Saudável",
    calorias: 588,
    proteinas: 25,
    carboidratos: 20,
    gorduras: 50,
    porcao_referencia: "1 colher sopa = 15g"
  },
  {
    nome: "Amendoim (torrado)",
    categoria: "Gordura Saudável",
    calorias: 567,
    proteinas: 26,
    carboidratos: 16,
    gorduras: 49,
    porcao_referencia: "1/4 xícara = 35g"
  },
  {
    nome: "Castanha do Pará",
    categoria: "Gordura Saudável",
    calorias: 656,
    proteinas: 14,
    carboidratos: 12,
    gorduras: 66,
    porcao_referencia: "3 unidades = 15g"
  },
  {
    nome: "Amêndoas",
    categoria: "Gordura Saudável",
    calorias: 579,
    proteinas: 21,
    carboidratos: 22,
    gorduras: 50,
    porcao_referencia: "1/4 xícara = 30g"
  },
  {
    nome: "Azeite de Oliva Extra Virgem",
    categoria: "Gordura Saudável",
    calorias: 884,
    proteinas: 0,
    carboidratos: 0,
    gorduras: 100,
    porcao_referencia: "1 colher sopa = 15ml"
  },
  {
    nome: "Óleo de Coco",
    categoria: "Gordura Saudável",
    calorias: 862,
    proteinas: 0,
    carboidratos: 0,
    gorduras: 100,
    porcao_referencia: "1 colher sopa = 15ml"
  },
  // 💡 ADICIONE MAIS GORDURAS SAUDÁVEIS AQUI
];

// ============================================================================
// LATICÍNIOS E DERIVADOS
// ============================================================================
export const laticinios: FoodItem[] = [
  {
    nome: "Iogurte Grego Natural (0% gordura)",
    categoria: "Laticínio",
    calorias: 59,
    proteinas: 10,
    carboidratos: 3.6,
    gorduras: 0.4,
    porcao_referencia: "1 pote = 170g"
  },
  {
    nome: "Queijo Cottage",
    categoria: "Laticínio",
    calorias: 98,
    proteinas: 11,
    carboidratos: 3.4,
    gorduras: 4.3,
    porcao_referencia: "1/2 xícara = 110g"
  },
  {
    nome: "Queijo Minas Frescal",
    categoria: "Laticínio",
    calorias: 264,
    proteinas: 17,
    carboidratos: 3,
    gorduras: 21,
    porcao_referencia: "1 fatia = 30g"
  },
  {
    nome: "Leite Desnatado",
    categoria: "Laticínio",
    calorias: 34,
    proteinas: 3.4,
    carboidratos: 5,
    gorduras: 0.1,
    porcao_referencia: "1 copo = 240ml"
  },
  {
    nome: "Whey Protein (isolado)",
    categoria: "Suplemento",
    calorias: 395,
    proteinas: 90,
    carboidratos: 2,
    gorduras: 1,
    porcao_referencia: "1 scoop = 30g"
  },
  // 💡 ADICIONE MAIS LATICÍNIOS AQUI
];

// ============================================================================
// FRUTAS
// ============================================================================
export const frutas: FoodItem[] = [
  {
    nome: "Banana Prata",
    categoria: "Fruta",
    calorias: 89,
    proteinas: 1.1,
    carboidratos: 23,
    gorduras: 0.3,
    porcao_referencia: "1 unidade média = 100g"
  },
  {
    nome: "Maçã",
    categoria: "Fruta",
    calorias: 52,
    proteinas: 0.3,
    carboidratos: 14,
    gorduras: 0.2,
    porcao_referencia: "1 unidade média = 180g"
  },
  {
    nome: "Morango",
    categoria: "Fruta",
    calorias: 32,
    proteinas: 0.7,
    carboidratos: 7.7,
    gorduras: 0.3,
    porcao_referencia: "1 xícara = 150g"
  },
  {
    nome: "Mamão Papaya",
    categoria: "Fruta",
    calorias: 43,
    proteinas: 0.5,
    carboidratos: 11,
    gorduras: 0.3,
    porcao_referencia: "1 fatia = 150g"
  },
  {
    nome: "Melancia",
    categoria: "Fruta",
    calorias: 30,
    proteinas: 0.6,
    carboidratos: 8,
    gorduras: 0.2,
    porcao_referencia: "1 fatia grande = 280g"
  },
  // 💡 ADICIONE MAIS FRUTAS AQUI
];

// ============================================================================
// VEGETAIS E LEGUMES
// ============================================================================
export const vegetais: FoodItem[] = [
  {
    nome: "Brócolis (cozido)",
    categoria: "Vegetal",
    calorias: 35,
    proteinas: 2.4,
    carboidratos: 7,
    gorduras: 0.4,
    porcao_referencia: "1 xícara = 156g"
  },
  {
    nome: "Espinafre (cru)",
    categoria: "Vegetal",
    calorias: 23,
    proteinas: 2.9,
    carboidratos: 3.6,
    gorduras: 0.4,
    porcao_referencia: "2 xícaras = 60g"
  },
  {
    nome: "Alface (crespa)",
    categoria: "Vegetal",
    calorias: 15,
    proteinas: 1.4,
    carboidratos: 2.9,
    gorduras: 0.2,
    porcao_referencia: "2 xícaras = 72g"
  },
  {
    nome: "Tomate",
    categoria: "Vegetal",
    calorias: 18,
    proteinas: 0.9,
    carboidratos: 3.9,
    gorduras: 0.2,
    porcao_referencia: "1 médio = 123g"
  },
  {
    nome: "Cenoura (crua)",
    categoria: "Vegetal",
    calorias: 41,
    proteinas: 0.9,
    carboidratos: 10,
    gorduras: 0.2,
    porcao_referencia: "1 média = 61g"
  },
  // 💡 ADICIONE MAIS VEGETAIS AQUI
];

// ============================================================================
// LEGUMINOSAS
// ============================================================================
export const leguminosas: FoodItem[] = [
  {
    nome: "Feijão Carioca (cozido)",
    categoria: "Leguminosa",
    calorias: 127,
    proteinas: 9,
    carboidratos: 23,
    gorduras: 0.5,
    porcao_referencia: "1 concha = 100g"
  },
  {
    nome: "Feijão Preto (cozido)",
    categoria: "Leguminosa",
    calorias: 132,
    proteinas: 8.9,
    carboidratos: 24,
    gorduras: 0.5,
    porcao_referencia: "1 concha = 100g"
  },
  {
    nome: "Grão de Bico (cozido)",
    categoria: "Leguminosa",
    calorias: 164,
    proteinas: 8.9,
    carboidratos: 27,
    gorduras: 2.6,
    porcao_referencia: "1 xícara = 164g"
  },
  {
    nome: "Lentilha (cozida)",
    categoria: "Leguminosa",
    calorias: 116,
    proteinas: 9,
    carboidratos: 20,
    gorduras: 0.4,
    porcao_referencia: "1 xícara = 198g"
  },
  // 💡 ADICIONE MAIS LEGUMINOSAS AQUI
];

// ============================================================================
// Função auxiliar para buscar alimentos por categoria
// ============================================================================
export function getAllFoods(): FoodItem[] {
  return [
    ...proteinasAnimais,
    ...carboidratosComplexos,
    ...gordurasSaudaveis,
    ...laticinios,
    ...frutas,
    ...vegetais,
    ...leguminosas,
  ];
}

export function getFoodsByCategory(categoria: string): FoodItem[] {
  return getAllFoods().filter(food => food.categoria === categoria);
}

export function searchFoods(termo: string): FoodItem[] {
  const termoLower = termo.toLowerCase();
  return getAllFoods().filter(food => 
    food.nome.toLowerCase().includes(termoLower)
  );
}

// ============================================================================
// Função para calcular macros de uma porção específica
// ============================================================================
export function calculatePortion(food: FoodItem, gramas: number) {
  const factor = gramas / 100;
  return {
    nome: food.nome,
    gramas,
    calorias: Math.round(food.calorias * factor),
    proteinas: Math.round(food.proteinas * factor * 10) / 10,
    carboidratos: Math.round(food.carboidratos * factor * 10) / 10,
    gorduras: Math.round(food.gorduras * factor * 10) / 10,
  };
}

// ============================================================================
// EXEMPLO DE USO:
// ============================================================================
// import { calculatePortion, searchFoods, proteinasAnimais } from './food-database';
//
// // Buscar um alimento
// const alimento = proteinasAnimais.find(f => f.nome.includes("Frango"));
//
// // Calcular porção de 200g
// if (alimento) {
//   const porcao = calculatePortion(alimento, 200);
//   console.log(porcao);
//   // Output: { nome: "Peito de Frango (grelhado)", gramas: 200, calorias: 330, proteinas: 62, carboidratos: 0, gorduras: 7.2 }
// }
// ============================================================================
