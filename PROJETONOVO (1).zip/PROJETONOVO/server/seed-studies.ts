import { storage } from "./storage";

const studyMaterials = [
  {
    titulo: "Python - Fundamentos Básicos",
    descricao: "Aprenda os conceitos fundamentais de Python: variáveis, tipos de dados, estruturas de controle e funções.",
    categoria: "Python",
    progresso: 0,
    data_inicio: null,
    data_conclusao: null,
    observacoes: "Link: https://docs.python.org/pt-br/3/tutorial/index.html\nTópicos: sintaxe básica, variáveis, tipos (int, float, str, bool), if/else, loops (for, while)"
  },
  {
    titulo: "Python - Estruturas de Dados",
    descricao: "Domine listas, tuplas, dicionários, sets e suas operações.",
    categoria: "Python",
    progresso: 0,
    data_inicio: null,
    data_conclusao: null,
    observacoes: "Link: https://docs.python.org/pt-br/3/tutorial/datastructures.html\nTópicos: listas, tuplas, dicionários, sets, comprehensions"
  },
  {
    titulo: "Python - Programação Orientada a Objetos",
    descricao: "Entenda classes, objetos, herança, polimorfismo e encapsulamento em Python.",
    categoria: "Python",
    progresso: 0,
    data_inicio: null,
    data_conclusao: null,
    observacoes: "Link: https://docs.python.org/pt-br/3/tutorial/classes.html\nTópicos: classes, objetos, métodos, herança, polimorfismo"
  },
  {
    titulo: "Python - Manipulação de Arquivos",
    descricao: "Aprenda a ler e escrever arquivos, trabalhar com JSON, CSV e outros formatos.",
    categoria: "Python",
    progresso: 0,
    data_inicio: null,
    data_conclusao: null,
    observacoes: "Link: https://docs.python.org/pt-br/3/tutorial/inputoutput.html\nTópicos: open(), read(), write(), json, csv, with statement"
  },
  {
    titulo: "Algoritmos - Ordenação e Busca",
    descricao: "Estude algoritmos clássicos de ordenação (bubble sort, merge sort, quick sort) e busca (linear, binária).",
    categoria: "Algoritmos",
    progresso: 0,
    data_inicio: null,
    data_conclusao: null,
    observacoes: "Recursos: visualgo.net, GeeksforGeeks\nTópicos: bubble sort, insertion sort, merge sort, quick sort, binary search"
  },
  {
    titulo: "Estruturas de Dados - Arrays e Linked Lists",
    descricao: "Compreenda arrays, listas ligadas simples e duplas, suas operações e complexidade.",
    categoria: "Estruturas de Dados",
    progresso: 0,
    data_inicio: null,
    data_conclusao: null,
    observacoes: "Link: https://www.geeksforgeeks.org/data-structures/\nTópicos: arrays, linked lists, operações básicas, Big O notation"
  },
  {
    titulo: "Estruturas de Dados - Pilhas e Filas",
    descricao: "Aprenda sobre pilhas (stacks) e filas (queues), suas aplicações práticas.",
    categoria: "Estruturas de Dados",
    progresso: 0,
    data_inicio: null,
    data_conclusao: null,
    observacoes: "Aplicações: navegador (pilha), fila de impressão, BFS\nTópicos: LIFO, FIFO, operações push/pop, enqueue/dequeue"
  },
  {
    titulo: "Git e Controle de Versão",
    descricao: "Domine os comandos essenciais do Git para versionamento de código.",
    categoria: "Ferramentas",
    progresso: 0,
    data_inicio: null,
    data_conclusao: null,
    observacoes: "Link: https://git-scm.com/book/pt-br/v2\nTópicos: init, clone, add, commit, push, pull, branch, merge"
  },
  {
    titulo: "Banco de Dados - SQL Básico",
    descricao: "Aprenda consultas SQL: SELECT, INSERT, UPDATE, DELETE, JOINs.",
    categoria: "Banco de Dados",
    progresso: 0,
    data_inicio: null,
    data_conclusao: null,
    observacoes: "Prática: SQLZoo, HackerRank SQL\nTópicos: SELECT, WHERE, JOIN, GROUP BY, ORDER BY, agregações"
  },
  {
    titulo: "APIs REST - Conceitos e Prática",
    descricao: "Entenda o que são APIs REST, métodos HTTP e como consumir APIs.",
    categoria: "Web Development",
    progresso: 0,
    data_inicio: null,
    data_conclusao: null,
    observacoes: "Link: https://restfulapi.net/\nTópicos: GET, POST, PUT, DELETE, status codes, JSON"
  },
  {
    titulo: "Python - Tratamento de Exceções",
    descricao: "Aprenda a tratar erros e exceções em Python de forma adequada.",
    categoria: "Python",
    progresso: 0,
    data_inicio: null,
    data_conclusao: null,
    observacoes: "Link: https://docs.python.org/pt-br/3/tutorial/errors.html\nTópicos: try, except, finally, raise, custom exceptions"
  },
  {
    titulo: "Complexidade Algorítmica - Big O",
    descricao: "Entenda notação Big O e como analisar a eficiência de algoritmos.",
    categoria: "Algoritmos",
    progresso: 0,
    data_inicio: null,
    data_conclusao: null,
    observacoes: "Link: https://www.bigocheatsheet.com/\nTópicos: O(1), O(n), O(log n), O(n²), análise de tempo e espaço"
  }
];

export async function seedStudies() {
  console.log("Adicionando materiais de estudo...");
  
  try {
    for (const study of studyMaterials) {
      await storage.createStudy(study);
    }
    console.log(`✓ ${studyMaterials.length} materiais de estudo adicionados com sucesso!`);
  } catch (error) {
    console.error("Erro ao adicionar materiais de estudo:", error);
  }
}
