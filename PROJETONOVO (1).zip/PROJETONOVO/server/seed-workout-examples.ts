import { storage } from "./storage";
import type { InsertWorkoutPlan, InsertMealPlan } from "@shared/schema";

// ============================================================================
// EXEMPLOS DE PLANOS DE TREINO
// ============================================================================
// 💡 ADICIONE SEUS PRÓPRIOS PLANOS AQUI - Copie o formato e adicione novos planos
// ============================================================================

export const exampleWorkoutPlans: InsertWorkoutPlan[] = [
  {
    nome: "Treino de Peito e Tríceps (Push A)",
    descricao: "Foco em hipertrofia de peito e tríceps com volume moderado",
    categoria: "Hipertrofia",
    data_criacao: new Date().toISOString().split('T')[0],
    exercicios: [
      {
        exercicio: "Supino Reto com Barra",
        series: 4,
        repeticoes: 8,
        peso: "80",
        observacoes: "Descanso de 90 segundos entre séries"
      },
      {
        exercicio: "Supino Inclinado com Halteres",
        series: 3,
        repeticoes: 10,
        peso: "28",
        observacoes: "Cada halter, total 56kg"
      },
      {
        exercicio: "Crucifixo Inclinado",
        series: 3,
        repeticoes: 12,
        peso: "16",
        observacoes: "Foco na contração no topo"
      },
      {
        exercicio: "Tríceps na Polia Alta",
        series: 3,
        repeticoes: 12,
        peso: "40",
        observacoes: "Cotovelos fixos, movimento controlado"
      },
      {
        exercicio: "Tríceps Testa com Barra W",
        series: 3,
        repeticoes: 10,
        peso: "30",
        observacoes: "Descer até quase tocar a testa"
      }
    ]
  },
  
  {
    nome: "Treino de Costas e Bíceps (Pull A)",
    descricao: "Foco em largura e espessura das costas",
    categoria: "Hipertrofia",
    data_criacao: new Date().toISOString().split('T')[0],
    exercicios: [
      {
        exercicio: "Barra Fixa (Pegada Pronada)",
        series: 4,
        repeticoes: 8,
        peso: "0",
        observacoes: "Peso corporal + 10kg (colete de peso)"
      },
      {
        exercicio: "Remada Curvada com Barra",
        series: 4,
        repeticoes: 10,
        peso: "70",
        observacoes: "Pegada pronada, puxar até o abdômen"
      },
      {
        exercicio: "Pulley Frente Pegada Aberta",
        series: 3,
        repeticoes: 12,
        peso: "60",
        observacoes: "Foco na contração das costas"
      },
      {
        exercicio: "Rosca Direta com Barra",
        series: 3,
        repeticoes: 10,
        peso: "35",
        observacoes: "Sem balanço do corpo"
      },
      {
        exercicio: "Rosca Martelo com Halteres",
        series: 3,
        repeticoes: 12,
        peso: "14",
        observacoes: "Cada halter"
      }
    ]
  },

  {
    nome: "Treino de Pernas Completo (Leg Day)",
    descricao: "Treino completo de quadríceps, posterior e panturrilhas",
    categoria: "Hipertrofia",
    data_criacao: new Date().toISOString().split('T')[0],
    exercicios: [
      {
        exercicio: "Agachamento Livre com Barra",
        series: 4,
        repeticoes: 10,
        peso: "100",
        observacoes: "Descer até paralelo ou abaixo"
      },
      {
        exercicio: "Leg Press 45°",
        series: 4,
        repeticoes: 12,
        peso: "200",
        observacoes: "Amplitude completa"
      },
      {
        exercicio: "Cadeira Extensora",
        series: 3,
        repeticoes: 15,
        peso: "50",
        observacoes: "Contração de 2 segundos no topo"
      },
      {
        exercicio: "Mesa Flexora",
        series: 3,
        repeticoes: 12,
        peso: "45",
        observacoes: "Movimento controlado"
      },
      {
        exercicio: "Stiff com Barra",
        series: 3,
        repeticoes: 12,
        peso: "60",
        observacoes: "Sentir alongamento posterior"
      },
      {
        exercicio: "Panturrilha no Leg Press",
        series: 4,
        repeticoes: 20,
        peso: "100",
        observacoes: "Amplitude máxima"
      }
    ]
  },

  {
    nome: "Treino de Ombros e Abdômen",
    descricao: "Desenvolvimento completo dos deltoides e core",
    categoria: "Hipertrofia",
    data_criacao: new Date().toISOString().split('T')[0],
    exercicios: [
      {
        exercicio: "Desenvolvimento com Barra Sentado",
        series: 4,
        repeticoes: 8,
        peso: "50",
        observacoes: "Pegada na largura dos ombros"
      },
      {
        exercicio: "Desenvolvimento com Halteres",
        series: 3,
        repeticoes: 10,
        peso: "20",
        observacoes: "Cada halter, movimento completo"
      },
      {
        exercicio: "Elevação Lateral com Halteres",
        series: 4,
        repeticoes: 12,
        peso: "12",
        observacoes: "Cotovelos levemente flexionados"
      },
      {
        exercicio: "Elevação Frontal com Anilha",
        series: 3,
        repeticoes: 12,
        peso: "10",
        observacoes: "Alternar com elevação lateral"
      },
      {
        exercicio: "Encolhimento com Halteres",
        series: 3,
        repeticoes: 15,
        peso: "32",
        observacoes: "Cada halter, segurar contração"
      },
      {
        exercicio: "Abdominal na Polia",
        series: 3,
        repeticoes: 20,
        peso: "40",
        observacoes: "Flexão apenas do tronco"
      }
    ]
  },

  // ============================================================================
  // 💡 ADICIONE MAIS PLANOS DE TREINO AQUI
  // ============================================================================
  // Exemplo de como adicionar um novo plano:
  /*
  {
    nome: "Nome do seu Plano",
    descricao: "Descrição do objetivo do plano",
    categoria: "Hipertrofia/Força/Resistência",
    data_criacao: new Date().toISOString().split('T')[0],
    exercicios: [
      {
        exercicio: "Nome do Exercício",
        series: 3,
        repeticoes: 10,
        peso: "50",
        observacoes: "Suas observações"
      },
      // Adicione mais exercícios...
    ]
  },
  */
];

// ============================================================================
// EXEMPLOS DE PLANOS ALIMENTARES
// ============================================================================
// 💡 ADICIONE SEUS PRÓPRIOS PLANOS AQUI - Copie o formato e adicione novos planos
// ============================================================================

export const exampleMealPlans: InsertMealPlan[] = [
  {
    nome: "Dieta Cutting 2200 kcal",
    descricao: "Plano para perda de gordura mantendo massa muscular - Alto proteína",
    calorias_totais: 2200,
    data_criacao: new Date().toISOString().split('T')[0],
    refeicoes: [
      {
        nome: "Omelete com Aveia e Frutas",
        refeicao: "cafe",
        calorias: 450,
        proteinas: "35",
        carboidratos: "45",
        gorduras: "12",
        observacoes: "3 ovos, 50g aveia, 1 banana, café preto"
      },
      {
        nome: "Whey Protein com Amendoim",
        refeicao: "lanche_manha",
        calorias: 280,
        proteinas: "30",
        carboidratos: "15",
        gorduras: "12",
        observacoes: "1 scoop whey + 20g pasta de amendoim"
      },
      {
        nome: "Frango com Arroz Integral e Brócolis",
        refeicao: "almoco",
        calorias: 600,
        proteinas: "55",
        carboidratos: "65",
        gorduras: "8",
        observacoes: "200g peito de frango, 100g arroz integral cozido, 150g brócolis"
      },
      {
        nome: "Iogurte Grego com Granola",
        refeicao: "lanche_tarde",
        calorias: 320,
        proteinas: "25",
        carboidratos: "35",
        gorduras: "8",
        observacoes: "200g iogurte grego natural + 30g granola"
      },
      {
        nome: "Salmão com Batata Doce e Salada",
        refeicao: "jantar",
        calorias: 550,
        proteinas: "45",
        carboidratos: "50",
        gorduras: "15",
        observacoes: "180g salmão, 150g batata doce, salada verde à vontade"
      }
    ]
  },

  {
    nome: "Dieta Bulking 3000 kcal",
    descricao: "Plano para ganho de massa muscular - Superávit calórico",
    calorias_totais: 3000,
    data_criacao: new Date().toISOString().split('T')[0],
    refeicoes: [
      {
        nome: "Panqueca de Aveia com Pasta de Amendoim",
        refeicao: "cafe",
        calorias: 650,
        proteinas: "40",
        carboidratos: "70",
        gorduras: "22",
        observacoes: "100g aveia, 4 ovos, 30g pasta de amendoim, 1 banana"
      },
      {
        nome: "Batata Doce com Atum",
        refeicao: "lanche_manha",
        calorias: 400,
        proteinas: "35",
        carboidratos: "50",
        gorduras: "6",
        observacoes: "200g batata doce + 1 lata atum"
      },
      {
        nome: "Filé de Frango com Arroz e Feijão",
        refeicao: "almoco",
        calorias: 850,
        proteinas: "70",
        carboidratos: "95",
        gorduras: "15",
        observacoes: "250g frango, 150g arroz branco, 100g feijão, salada"
      },
      {
        nome: "Shake Hipercalórico",
        refeicao: "lanche_tarde",
        calorias: 550,
        proteinas: "40",
        carboidratos: "60",
        gorduras: "18",
        observacoes: "1 scoop whey, 1 banana, 50g aveia, 20g pasta amendoim, 300ml leite"
      },
      {
        nome: "Carne Vermelha com Macarrão Integral",
        refeicao: "jantar",
        calorias: 550,
        proteinas: "50",
        carboidratos: "55",
        gorduras: "12",
        observacoes: "200g carne magra, 100g macarrão integral cozido, legumes"
      }
    ]
  },

  {
    nome: "Dieta Manutenção 2500 kcal",
    descricao: "Plano balanceado para manter peso e composição corporal",
    calorias_totais: 2500,
    data_criacao: new Date().toISOString().split('T')[0],
    refeicoes: [
      {
        nome: "Tapioca com Queijo e Ovo",
        refeicao: "cafe",
        calorias: 420,
        proteinas: "25",
        carboidratos: "50",
        gorduras: "14",
        observacoes: "100g tapioca, 2 ovos, 30g queijo minas"
      },
      {
        nome: "Frutas com Castanhas",
        refeicao: "lanche_manha",
        calorias: 250,
        proteinas: "8",
        carboidratos: "35",
        gorduras: "10",
        observacoes: "1 maçã, 1 banana, 30g mix de castanhas"
      },
      {
        nome: "Tilápia com Quinoa e Legumes",
        refeicao: "almoco",
        calorias: 650,
        proteinas: "55",
        carboidratos: "70",
        gorduras: "10",
        observacoes: "200g tilápia, 100g quinoa cozida, 200g legumes variados"
      },
      {
        nome: "Sanduíche Natural de Frango",
        refeicao: "lanche_tarde",
        calorias: 380,
        proteinas: "30",
        carboidratos: "40",
        gorduras: "10",
        observacoes: "Pão integral, 100g frango desfiado, alface, tomate"
      },
      {
        nome: "Omelete com Vegetais e Batata",
        refeicao: "jantar",
        calorias: 480,
        proteinas: "35",
        carboidratos: "45",
        gorduras: "15",
        observacoes: "4 ovos, 150g batata inglesa, vegetais variados"
      },
      {
        nome: "Cottage com Mel",
        refeicao: "ceia",
        calorias: 320,
        proteinas: "28",
        carboidratos: "35",
        gorduras: "8",
        observacoes: "200g cottage + 1 colher mel + canela"
      }
    ]
  },

  // ============================================================================
  // 💡 ADICIONE MAIS PLANOS ALIMENTARES AQUI
  // ============================================================================
  // Exemplo de como adicionar um novo plano:
  /*
  {
    nome: "Nome do seu Plano Alimentar",
    descricao: "Descrição do objetivo (cutting/bulking/manutenção)",
    calorias_totais: 2500, // Total de calorias do dia
    data_criacao: new Date().toISOString().split('T')[0],
    refeicoes: [
      {
        nome: "Nome da Refeição",
        refeicao: "cafe/lanche_manha/almoco/lanche_tarde/jantar/ceia",
        calorias: 400,
        proteinas: "30",
        carboidratos: "40",
        gorduras: "10",
        observacoes: "Detalhes dos alimentos e quantidades"
      },
      // Adicione mais refeições...
    ]
  },
  */
];

// ============================================================================
// Função para adicionar os planos de exemplo ao banco de dados
// ============================================================================
export async function seedWorkoutAndMealPlans() {
  try {
    console.log("Adicionando planos de exemplo ao banco de dados...");
    
    // Adicionar planos de treino
    for (const plan of exampleWorkoutPlans) {
      await storage.createWorkoutPlan(plan);
    }
    console.log(`✓ ${exampleWorkoutPlans.length} planos de treino adicionados!`);
    
    // Adicionar planos alimentares
    for (const plan of exampleMealPlans) {
      await storage.createMealPlan(plan);
    }
    console.log(`✓ ${exampleMealPlans.length} planos alimentares adicionados!`);
    
    console.log("✓ Todos os planos de exemplo foram adicionados com sucesso!");
  } catch (error) {
    console.error("Erro ao adicionar planos de exemplo:", error);
  }
}
