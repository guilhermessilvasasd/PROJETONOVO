# 📚 Guia de Uso - Planos de Treino e Alimentação

## 🎯 O que foi implementado

Seu aplicativo agora possui:

✅ **Planos de Treino Completos** - Múltiplos exercícios por plano  
✅ **Planos de Alimentação Completos** - Múltiplas refeições por dia  
✅ **Calculadora de TDEE/KCAL** - Baseada na fórmula Mifflin-St Jeor  
✅ **Banco de Dados de Alimentos** - Mais de 50 alimentos com macros  

## 📁 Arquivos com Exemplos

### 1. `server/seed-workout-examples.ts`
**Contém:** 4 planos de treino e 3 planos alimentares de exemplo

**Planos de Treino Incluídos:**
- Treino de Peito e Tríceps (Push A) - 5 exercícios
- Treino de Costas e Bíceps (Pull A) - 5 exercícios
- Treino de Pernas Completo - 6 exercícios
- Treino de Ombros e Abdômen - 6 exercícios

**Planos Alimentares Incluídos:**
- Dieta Cutting 2200 kcal - 5 refeições
- Dieta Bulking 3000 kcal - 5 refeições
- Dieta Manutenção 2500 kcal - 6 refeições

### 2. `server/food-database.ts`
**Contém:** Banco de dados completo de alimentos com macros

**Categorias disponíveis:**
- Proteínas Animais (7 alimentos)
- Carboidratos Complexos (9 alimentos)
- Gorduras Saudáveis (7 alimentos)
- Laticínios (5 alimentos)
- Frutas (5 alimentos)
- Vegetais (5 alimentos)
- Leguminosas (4 alimentos)

## 🔧 Como Adicionar Mais Exemplos

### Adicionar Novos Planos de Treino

Abra `server/seed-workout-examples.ts` e procure por este comentário:

```typescript
// 💡 ADICIONE MAIS PLANOS DE TREINO AQUI
```

Copie e cole este template abaixo do comentário:

```typescript
{
  nome: "Nome do seu Plano",
  descricao: "Descrição do objetivo do plano",
  categoria: "Hipertrofia/Força/Resistência",
  data_criacao: new Date().toISOString().split('T')[0],
  exercicios: [
    {
      exercicio: "Nome do Exercício",
      series: 3,
      repeticoes: 10,
      peso: "50",
      observacoes: "Suas observações"
    },
    {
      exercicio: "Outro Exercício",
      series: 4,
      repeticoes: 8,
      peso: "60",
      observacoes: "Mais observações"
    }
    // Adicione quantos exercícios quiser!
  ]
},
```

### Adicionar Novos Planos Alimentares

Procure por este comentário no mesmo arquivo:

```typescript
// 💡 ADICIONE MAIS PLANOS ALIMENTARES AQUI
```

Copie e cole este template:

```typescript
{
  nome: "Nome do seu Plano Alimentar",
  descricao: "Descrição do objetivo (cutting/bulking/manutenção)",
  calorias_totais: 2500,
  data_criacao: new Date().toISOString().split('T')[0],
  refeicoes: [
    {
      nome: "Nome da Refeição",
      refeicao: "cafe", // cafe, lanche_manha, almoco, lanche_tarde, jantar, ceia
      calorias: 400,
      proteinas: "30",
      carboidratos: "40",
      gorduras: "10",
      observacoes: "Detalhes dos alimentos e quantidades"
    }
    // Adicione quantas refeições quiser!
  ]
},
```

### Adicionar Novos Alimentos ao Banco de Dados

Abra `server/food-database.ts` e procure pelos comentários `💡 ADICIONE MAIS...` nas diferentes categorias.

Exemplo para adicionar uma proteína:

```typescript
// Procure por: 💡 ADICIONE MAIS PROTEÍNAS ANIMAIS AQUI
{
  nome: "Nome do Alimento",
  categoria: "Proteína Animal",
  calorias: 150,      // kcal por 100g
  proteinas: 25,      // gramas por 100g
  carboidratos: 0,    // gramas por 100g
  gorduras: 5,        // gramas por 100g
  porcao_referencia: "1 porção = 150g"
},
```

## 🔄 Como Recarregar os Exemplos

### Método 1: Deletar os planos existentes via API

Use a interface do aplicativo para deletar todos os planos de treino e alimentação. Na próxima vez que reiniciar o servidor, os exemplos serão adicionados novamente.

### Método 2: Limpar o banco de dados (apenas desenvolvimento)

```bash
npm run db:push
```

Isso sincroniza o schema. Depois reinicie o servidor e os exemplos serão adicionados automaticamente.

## 🎮 Como Usar via API

### Buscar todos os planos de treino:
```bash
GET /api/workout-plans
```

### Buscar um plano específico:
```bash
GET /api/workout-plans/:id
```

### Criar um novo plano:
```bash
POST /api/workout-plans
Content-Type: application/json

{
  "nome": "Meu Plano de Treino",
  "descricao": "Descrição",
  "categoria": "Hipertrofia",
  "data_criacao": "2025-10-27",
  "exercicios": [
    {
      "exercicio": "Supino",
      "series": 4,
      "repeticoes": 10,
      "peso": "80"
    }
  ]
}
```

### Deletar um plano:
```bash
DELETE /api/workout-plans/:id
```

### Calcular TDEE:
```bash
POST /api/calculate-tdee
Content-Type: application/json

{
  "peso": "80",
  "altura": 175,
  "idade": 25,
  "sexo": "masculino",
  "nivel_atividade": "moderado",
  "objetivo": "ganhar_massa"
}
```

**Retorna:**
```json
{
  "tmb": 1750,
  "tdee": 2713,
  "calorias_objetivo": 3213,
  "proteinas": 176,
  "carboidratos": 402,
  "gorduras": 89
}
```

## 🧮 Usando a Calculadora de Macros

No arquivo `server/food-database.ts`, você pode usar as funções:

```typescript
import { calculatePortion, searchFoods } from './food-database';

// Buscar alimento
const frango = searchFoods("frango")[0];

// Calcular porção de 200g
const porcao = calculatePortion(frango, 200);
// Retorna: { nome, gramas, calorias, proteinas, carboidratos, gorduras }
```

## 📊 Valores de Referência

### Níveis de Atividade:
- `sedentario` - Pouco ou nenhum exercício (1.2x)
- `leve` - Exercício 1-3 dias/semana (1.375x)
- `moderado` - Exercício 3-5 dias/semana (1.55x)
- `intenso` - Exercício 6-7 dias/semana (1.725x)
- `muito_intenso` - Exercício 2x/dia (1.9x)

### Objetivos:
- `perder_peso` - Déficit de 500 kcal
- `manter_peso` - Manutenção
- `ganhar_massa` - Superávit de 500 kcal

## 🎯 Próximos Passos

1. **Explore os exemplos** - Veja os planos já criados em `/api/workout-plans` e `/api/meal-plans`
2. **Adicione seus próprios** - Use os templates acima para criar planos personalizados
3. **Use o banco de alimentos** - Consulte `server/food-database.ts` para montar suas refeições
4. **Calcule seu TDEE** - Use `/api/calculate-tdee` para saber suas calorias ideais

## 💡 Dicas

- Os planos de exemplo são adicionados **automaticamente** na primeira vez que o servidor inicia
- Você pode modificar os exemplos em `server/seed-workout-examples.ts` antes de iniciar
- O banco de alimentos é apenas referência - não é armazenado no banco de dados
- Use a calculadora de TDEE para determinar calorias antes de criar planos alimentares

---

**Desenvolvido com ❤️ - Sistema de Gerenciamento Pessoal**
