import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const finances = pgTable("finances", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  descricao: text("descricao").notNull(),
  valor: text("valor").notNull(),
  categoria: text("categoria").notNull(),
  tipo: text("tipo").notNull(),
  data: text("data").notNull(),
});

export const workouts = pgTable("workouts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  exercicio: text("exercicio").notNull(),
  series: integer("series").notNull(),
  repeticoes: integer("repeticoes").notNull(),
  peso: text("peso"),
  data: text("data").notNull(),
  observacoes: text("observacoes"),
});

export const meals = pgTable("meals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nome: text("nome").notNull(),
  calorias: integer("calorias"),
  proteinas: text("proteinas"),
  carboidratos: text("carboidratos"),
  gorduras: text("gorduras"),
  data: text("data").notNull(),
  refeicao: text("refeicao").notNull(),
  observacoes: text("observacoes"),
});

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  titulo: text("titulo").notNull(),
  descricao: text("descricao"),
  data: text("data").notNull(),
  hora: text("hora"),
  concluida: boolean("concluida").notNull().default(false),
  prioridade: text("prioridade").notNull(),
});

export const studies = pgTable("studies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  titulo: text("titulo").notNull(),
  descricao: text("descricao"),
  categoria: text("categoria").notNull(),
  progresso: integer("progresso").notNull().default(0),
  data_inicio: text("data_inicio"),
  data_conclusao: text("data_conclusao"),
  observacoes: text("observacoes"),
});

export const workoutPlans = pgTable("workout_plans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nome: text("nome").notNull(),
  descricao: text("descricao"),
  categoria: text("categoria").notNull(),
  data_criacao: text("data_criacao").notNull(),
});

export const workoutPlanExercises = pgTable("workout_plan_exercises", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workout_plan_id: varchar("workout_plan_id").notNull(),
  exercicio: text("exercicio").notNull(),
  series: integer("series").notNull(),
  repeticoes: integer("repeticoes").notNull(),
  peso: text("peso"),
  observacoes: text("observacoes"),
  ordem: integer("ordem").notNull(),
});

export const mealPlans = pgTable("meal_plans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nome: text("nome").notNull(),
  descricao: text("descricao"),
  calorias_totais: integer("calorias_totais").notNull(),
  data_criacao: text("data_criacao").notNull(),
});

export const mealPlanItems = pgTable("meal_plan_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  meal_plan_id: varchar("meal_plan_id").notNull(),
  nome: text("nome").notNull(),
  refeicao: text("refeicao").notNull(),
  calorias: integer("calorias"),
  proteinas: text("proteinas"),
  carboidratos: text("carboidratos"),
  gorduras: text("gorduras"),
  observacoes: text("observacoes"),
  ordem: integer("ordem").notNull(),
});

export const userMetrics = pgTable("user_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  idade: integer("idade").notNull(),
  peso: text("peso").notNull(),
  altura: integer("altura").notNull(),
  sexo: text("sexo").notNull(),
  nivel_atividade: text("nivel_atividade").notNull(),
  objetivo: text("objetivo").notNull(),
  data_atualizacao: text("data_atualizacao").notNull(),
});

// Finance
export interface Finance {
  id: string;
  descricao: string;
  valor: string;
  categoria: string;
  tipo: "receita" | "despesa";
  data: string;
}

export const insertFinanceSchema = z.object({
  descricao: z.string().min(1, "Descrição é obrigatória"),
  valor: z.string().min(1, "Valor é obrigatório"),
  categoria: z.string().min(1, "Categoria é obrigatória"),
  tipo: z.enum(["receita", "despesa"]),
  data: z.string().min(1, "Data é obrigatória"),
});

export type InsertFinance = z.infer<typeof insertFinanceSchema>;

// Workout
export interface Workout {
  id: string;
  exercicio: string;
  series: number;
  repeticoes: number;
  peso: string | null;
  data: string;
  observacoes: string | null;
}

export const insertWorkoutSchema = z.object({
  exercicio: z.string().min(1, "Exercício é obrigatório"),
  series: z.coerce.number().min(1, "Séries deve ser maior que 0"),
  repeticoes: z.coerce.number().min(1, "Repetições deve ser maior que 0"),
  peso: z.string().optional(),
  data: z.string().min(1, "Data é obrigatória"),
  observacoes: z.string().optional(),
});

export type InsertWorkout = z.infer<typeof insertWorkoutSchema>;

// Meal
export interface Meal {
  id: string;
  nome: string;
  calorias: number | null;
  proteinas: string | null;
  carboidratos: string | null;
  gorduras: string | null;
  data: string;
  refeicao: string;
  observacoes: string | null;
}

export const insertMealSchema = z.object({
  nome: z.string().min(1, "Nome é obrigatório"),
  calorias: z.coerce.number().optional(),
  proteinas: z.string().optional(),
  carboidratos: z.string().optional(),
  gorduras: z.string().optional(),
  data: z.string().min(1, "Data é obrigatória"),
  refeicao: z.string().min(1, "Tipo de refeição é obrigatório"),
  observacoes: z.string().optional(),
});

export type InsertMeal = z.infer<typeof insertMealSchema>;

// Task
export interface Task {
  id: string;
  titulo: string;
  descricao: string | null;
  data: string;
  hora: string | null;
  concluida: boolean;
  prioridade: string;
}

export const insertTaskSchema = z.object({
  titulo: z.string().min(1, "Título é obrigatório"),
  descricao: z.string().optional(),
  data: z.string().min(1, "Data é obrigatória"),
  hora: z.string().optional(),
  concluida: z.boolean().default(false),
  prioridade: z.string().min(1, "Prioridade é obrigatória"),
});

export type InsertTask = z.infer<typeof insertTaskSchema>;

// Study
export interface Study {
  id: string;
  titulo: string;
  descricao: string | null;
  categoria: string;
  progresso: number;
  data_inicio: string | null;
  data_conclusao: string | null;
  observacoes: string | null;
}

export const insertStudySchema = z.object({
  titulo: z.string().min(1, "Título é obrigatório"),
  descricao: z.string().optional(),
  categoria: z.string().min(1, "Categoria é obrigatória"),
  progresso: z.coerce.number().min(0).max(100).default(0),
  data_inicio: z.string().optional(),
  data_conclusao: z.string().optional(),
  observacoes: z.string().optional(),
});

export type InsertStudy = z.infer<typeof insertStudySchema>;

// Workout Plan
export interface WorkoutPlan {
  id: string;
  nome: string;
  descricao: string | null;
  categoria: string;
  data_criacao: string;
}

export interface WorkoutPlanExercise {
  id: string;
  workout_plan_id: string;
  exercicio: string;
  series: number;
  repeticoes: number;
  peso: string | null;
  observacoes: string | null;
  ordem: number;
}

export const insertWorkoutPlanSchema = z.object({
  nome: z.string().min(1, "Nome é obrigatório"),
  descricao: z.string().optional(),
  categoria: z.string().min(1, "Categoria é obrigatória"),
  data_criacao: z.string().min(1, "Data é obrigatória"),
  exercicios: z.array(z.object({
    exercicio: z.string().min(1, "Exercício é obrigatório"),
    series: z.coerce.number().min(1, "Séries deve ser maior que 0"),
    repeticoes: z.coerce.number().min(1, "Repetições deve ser maior que 0"),
    peso: z.string().optional(),
    observacoes: z.string().optional(),
  })),
});

export type InsertWorkoutPlan = z.infer<typeof insertWorkoutPlanSchema>;

// Meal Plan
export interface MealPlan {
  id: string;
  nome: string;
  descricao: string | null;
  calorias_totais: number;
  data_criacao: string;
}

export interface MealPlanItem {
  id: string;
  meal_plan_id: string;
  nome: string;
  refeicao: string;
  calorias: number | null;
  proteinas: string | null;
  carboidratos: string | null;
  gorduras: string | null;
  observacoes: string | null;
  ordem: number;
}

export const insertMealPlanSchema = z.object({
  nome: z.string().min(1, "Nome é obrigatório"),
  descricao: z.string().optional(),
  calorias_totais: z.coerce.number().min(0, "Calorias não podem ser negativas"),
  data_criacao: z.string().min(1, "Data é obrigatória"),
  refeicoes: z.array(z.object({
    nome: z.string().min(1, "Nome é obrigatório"),
    refeicao: z.string().min(1, "Tipo de refeição é obrigatório"),
    calorias: z.coerce.number().optional(),
    proteinas: z.string().optional(),
    carboidratos: z.string().optional(),
    gorduras: z.string().optional(),
    observacoes: z.string().optional(),
  })),
});

export type InsertMealPlan = z.infer<typeof insertMealPlanSchema>;

// User Metrics
export interface UserMetrics {
  id: string;
  idade: number;
  peso: string;
  altura: number;
  sexo: string;
  nivel_atividade: string;
  objetivo: string;
  data_atualizacao: string;
}

export const insertUserMetricsSchema = z.object({
  idade: z.coerce.number().min(1, "Idade deve ser maior que 0"),
  peso: z.string().min(1, "Peso é obrigatório"),
  altura: z.coerce.number().min(1, "Altura deve ser maior que 0"),
  sexo: z.enum(["masculino", "feminino"]),
  nivel_atividade: z.enum(["sedentario", "leve", "moderado", "intenso", "muito_intenso"]),
  objetivo: z.enum(["perder_peso", "manter_peso", "ganhar_massa"]),
  data_atualizacao: z.string().min(1, "Data é obrigatória"),
});

export type InsertUserMetrics = z.infer<typeof insertUserMetricsSchema>;
